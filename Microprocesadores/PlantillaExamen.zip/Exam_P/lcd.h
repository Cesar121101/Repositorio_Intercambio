#ifndef __LCD_H
#define __LCD_H
#include "stm32f4xx_hal.h"
int init_LCD(void);
#endif