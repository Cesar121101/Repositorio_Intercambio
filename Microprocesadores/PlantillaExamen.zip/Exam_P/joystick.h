#ifndef __JOYSTICK_H
#define __JOYSTICK_H
	int init_Joystick (void);
#endif
