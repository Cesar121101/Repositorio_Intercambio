#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "stm32f4xx_hal.h"
#include <stdlib.h> 
#include "stdio.h"
#include "lcd.h"

/*----------------------------------------------------------------------------
 *      Thread 1 'Thread_Name': Sample thread
 *---------------------------------------------------------------------------*/
 
osThreadId_t Listener;                        // thread id
extern osMessageQueueId_t queue_lcd; 
void Listener_Func (void *argument);                   // thread function

int init_Listener (void) {
  Listener = osThreadNew(Listener_Func, NULL, NULL);
  if (Listener == NULL) {
    return(-1);
  }
	LCD_Init();
	LCD_clear();
  return(0);
}
 
void Listener_Func (void *argument) {
	osStatus_t status;
	uint8_t linea;
	uint8_t letra;
  while (1) {
    osMessageQueueGet(queue_lcd, &linea, NULL, 10U);   // wait for message
		switch (linea){
			case 1:
				osMessageQueueGet(queue_lcd, &letra, NULL, 10U);   // wait for message
				symbolToLocalBuffer(1,letra);
				break;
			case 2:
				osMessageQueueGet(queue_lcd, &letra, NULL, 10U);   // wait for message
				symbolToLocalBuffer(2,letra);
				break;
		}
		LCD_update();
	}
}
