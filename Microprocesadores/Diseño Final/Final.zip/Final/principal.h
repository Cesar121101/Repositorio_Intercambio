#ifndef __principal_H
#define __principal_H
	int init_Principal(void);
#endif