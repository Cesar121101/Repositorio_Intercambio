#ifndef __TEMPERATURA_H
#define __TEMPERATURA_H
	int init_Temperatura (void);
	int init_Temperatura_test (void);
#endif
