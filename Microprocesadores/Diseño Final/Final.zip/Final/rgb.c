#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "stm32f4xx_hal.h"
#include "rgb.h"

/*----------------------------------------------------------------------------
 *      Thread 1 'Thread_Name': Sample thread
 *---------------------------------------------------------------------------*/
 
osThreadId_t rgb;                        // thread id
osMessageQueueId_t queue_rgb; 

void ThreadRGB (void *argument);                   // thread function
void initLeds(void){
	GPIO_InitTypeDef GPIO_InitStruct;
  
  __HAL_RCC_GPIOD_CLK_ENABLE();
	
  GPIO_InitStruct.Pin = GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
	//Apagar los leds incialmente;
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13, GPIO_PIN_SET); 
}  
 
int init_RGB (void) {
  rgb = osThreadNew(ThreadRGB, NULL, NULL);
  if (rgb == NULL) {
    return(-1);
  }
	initLeds();
	queue_rgb = osMessageQueueNew(4, sizeof(msgQueue_RGB), NULL);
  return(0);
}
 
void ThreadRGB (void *argument) {
	msgQueue_RGB mensaje;
	float x;
  while (1) { 
		osMessageQueueGet(queue_rgb, &mensaje, NULL, osWaitForever);
		if(mensaje.Tm > 0 ){
			x = mensaje.Tr - mensaje.Tm;
			if (x >= 5.0) {
				// Rojo
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, GPIO_PIN_SET);
			} 
			else if (x >= 0.0 && x < 5.0) {
				// Verde + Rojo
				//HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, GPIO_PIN_SET);
			} 
			else if (x > -5.0 && x < 0.0) {
				// Verde + Azul
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, GPIO_PIN_RESET);
			} 
			else if (x <= -5.0) {
				// Azul
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);
				HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, GPIO_PIN_RESET);
			} 
		}else{
			// Apagar todos los LEDs
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, GPIO_PIN_SET);
		}
	}
}

void ThreadRGB_test(void *argument);
int init_RGB_test(void) {
  osThreadId_t rgb_test = osThreadNew(ThreadRGB_test, NULL, NULL);
  if (rgb_test == NULL) {
    return(-1);
  }
  return(0);
}
 
void ThreadRGB_test(void *argument) {
	msgQueue_RGB mensajeRGB;
	while(1){
		mensajeRGB.Tm = 20;
		mensajeRGB.Tr = 25;
		osMessageQueuePut(queue_rgb, &mensajeRGB, 0U, 0U);
		osDelay(1000);
		mensajeRGB.Tm = 21;
		mensajeRGB.Tr = 25;
		osMessageQueuePut(queue_rgb, &mensajeRGB, 0U, 0U);
		osDelay(1000);
		mensajeRGB.Tm = 25;
		mensajeRGB.Tr = 23;
		osMessageQueuePut(queue_rgb, &mensajeRGB, 0U, 0U);
		osDelay(1000);
		mensajeRGB.Tm = 25;
		mensajeRGB.Tr = 20;
		osMessageQueuePut(queue_rgb, &mensajeRGB, 0U, 0U);
		osDelay(1000);
	}
}