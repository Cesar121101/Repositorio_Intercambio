#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "stm32f4xx_hal.h"
#include "joystick.h"
#include <stdlib.h> 
 
/*----------------------------------------------------------------------------
 *      Thread 1 'Thread_Name': Sample thread
 *---------------------------------------------------------------------------*/

osThreadId_t joystick;                        // thread id
osMessageQueueId_t queue_joystick;  
 
osTimerId_t timsoft1;
osTimerId_t timsoft2;
osTimerId_t timsoft3;

uint8_t boton;

void THJoystick (void *argument);                   // thread function

void Timer1_Callback(){
	osTimerStart(timsoft2,150);
	osTimerStart(timsoft3,950);
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_10) == GPIO_PIN_SET){ //Arriba
		boton = 1;
	}
	else if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_11) == GPIO_PIN_SET){ //Derecha
		boton = 2;
	}
	else if(HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_12) == GPIO_PIN_SET){ //Abajo
		boton = 3;
	}
	else if(HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_14) == GPIO_PIN_SET){ //Izquierda
		boton = 4;
	}
	else if(HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_15) == GPIO_PIN_SET){ //Centro
		boton = 5;
	}
}

void Timer2_Callback(){
	MSGQUEUE_JOYSTICK mensaje;
	switch(boton){
		case 1:
			if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_10) == GPIO_PIN_RESET){
				mensaje.joystick_value = boton;
				mensaje.pulsacion = 0;
				osMessageQueuePut(queue_joystick, &mensaje, 0U, 0U); //Queue
			}
			break;
		case 2:
			if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_11) == GPIO_PIN_RESET){
				mensaje.joystick_value = boton;
				mensaje.pulsacion = 0;
				osMessageQueuePut(queue_joystick, &mensaje, 0U, 0U); //Queue
			}
			break;
		case 3:
			if(HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_12) == GPIO_PIN_RESET){
				mensaje.joystick_value = boton;
				mensaje.pulsacion = 0;
				osMessageQueuePut(queue_joystick, &mensaje, 0U, 0U); //Queue
			}
			break;
		case 4:
			if(HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_14) == GPIO_PIN_RESET){
				mensaje.joystick_value = boton;
				mensaje.pulsacion = 0;
				osMessageQueuePut(queue_joystick, &mensaje, 0U, 0U); //Queue
			}
			break;
		case 5:
			if(HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_15) == GPIO_PIN_RESET){
				mensaje.joystick_value = boton;
				mensaje.pulsacion = 0;
				osMessageQueuePut(queue_joystick, &mensaje, 0U, 0U); //Queue
			}
			break;
	}
}

void Timer3_Callback(){
	MSGQUEUE_JOYSTICK mensaje;
	switch(boton){
		case 1:
			if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_10) == GPIO_PIN_SET){
				mensaje.joystick_value = boton;
				mensaje.pulsacion = 1;
				osMessageQueuePut(queue_joystick, &mensaje, 0U, 0U); //Queue
			}
			break;
		case 2:
			if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_11) == GPIO_PIN_SET){
				mensaje.joystick_value = boton;
				mensaje.pulsacion = 1;
				osMessageQueuePut(queue_joystick, &mensaje, 0U, 0U); //Queue
			}
			break;
		case 3:
			if(HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_12) == GPIO_PIN_SET){
				mensaje.joystick_value = boton;
				mensaje.pulsacion = 1;
				osMessageQueuePut(queue_joystick, &mensaje, 0U, 0U); //Queue
			}
			break;
		case 4:
			if(HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_14) == GPIO_PIN_SET){
				mensaje.joystick_value = boton;
				mensaje.pulsacion = 1;
				osMessageQueuePut(queue_joystick, &mensaje, 0U, 0U); //Queue
			}
			break;
		case 5:
			if(HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_15) == GPIO_PIN_SET){
				mensaje.joystick_value = boton;
				mensaje.pulsacion = 1;
				osMessageQueuePut(queue_joystick, &mensaje, 0U, 0U); //Queue
			}
			break;
	}
}

int init_Joystick (void) {
  joystick = osThreadNew(THJoystick, NULL, NULL);
  if (joystick == NULL) {
    return(-1);
  }
	queue_joystick = osMessageQueueNew(16, sizeof(MSGQUEUE_JOYSTICK), NULL);
  return(0);
}
 
void THJoystick (void *argument) {
	timsoft1 = osTimerNew(Timer1_Callback, osTimerOnce, NULL, NULL);
	timsoft2 = osTimerNew(Timer2_Callback, osTimerOnce, NULL, NULL);
	timsoft3 = osTimerNew(Timer3_Callback, osTimerOnce, NULL, NULL);
  uint32_t flags;
	while (1) {	
		flags = osThreadFlagsWait(0x01, osFlagsWaitAny, osWaitForever);
		switch(flags)
		{
			case 1:
				osTimerStart(timsoft1, 50);
		}
  }
}

void THJoystick_test (void *argument);

int init_Joystick_test(void) {
  osThreadId_t joystick_test = osThreadNew(THJoystick_test, NULL, NULL);
  if (joystick_test == NULL) {
    return(-1);
  }
  return(0);
}
 
uint8_t pulsaciones;
uint8_t duracion;
void THJoystick_test(void *argument) {
	MSGQUEUE_JOYSTICK mensaje;
	while (1) {	
		osMessageQueueGet(queue_joystick, &mensaje, NULL, osWaitForever);
		pulsaciones = mensaje.joystick_value;
		duracion = mensaje.pulsacion;
  }
}