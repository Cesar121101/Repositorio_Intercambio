#ifndef __RGB_H
#define __RGB_H

	typedef struct {                               
			float Tm;
			float Tr;
	} msgQueue_RGB;

	int init_RGB (void);
#endif
