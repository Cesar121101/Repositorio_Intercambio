#ifndef __clock_H
#define __clock_H
	int init_Clock(void);
	int init_Clock_Test(void);
#endif