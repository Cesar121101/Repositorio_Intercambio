#ifndef __COM_H
#define __COM_H
	typedef struct {                               
		char informacion[3];
		char cadenaRecibir[8];
		char final;
	} msgQueue_Recibir;

	typedef struct { 
		char cadenaEnviar[39];
	} msgQueue_Enviar;

	int init_COM(void);
	int init_COM_test(void);
#endif
