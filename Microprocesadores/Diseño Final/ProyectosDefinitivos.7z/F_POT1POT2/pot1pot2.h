#ifndef __pot1pot2_H
#define __pot1pot2_H
	typedef struct {                               
		float pot1;
		float pot2;
	} msgQueue_ADC;
	
	int init_ADC(void);
	int init_ADC_test(void);
#endif
